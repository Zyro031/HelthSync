import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.example.pi.R

class ImcActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_imc)

        val etPeso = findViewById<EditText>(R.id.etPeso)
        val etAltura = findViewById<EditText>(R.id.etAltura)
        val cbConverterMetros = findViewById<CheckBox>(R.id.cbConverterMetros)
        val spinnerSexo = findViewById<Spinner>(R.id.spinnerSexo)
        val spinnerFaixaEtaria = findViewById<Spinner>(R.id.spinnerFaixaEtaria)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val cardResultado = findViewById<CardView>(R.id.cardResultado)
        val tvResultadoIMC = findViewById<TextView>(R.id.tvResultadoIMC)
        val tvClassificacao = findViewById<TextView>(R.id.tvClassificacao)
        val tvSugestoes = findViewById<TextView>(R.id.tvSugestoes)
        val btnSalvar = findViewById<Button>(R.id.btnSalvar)

        btnCalcular.setOnClickListener {
            val pesoText = etPeso.text.toString()
            val alturaText = etAltura.text.toString()

            if (pesoText.isEmpty() || alturaText.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                val peso = pesoText.toDouble()
                var altura = alturaText.toDouble()

                // Converter cm para metros se necessário
                if (!cbConverterMetros.isChecked) {
                    altura /= 100
                }

                // Calcular IMC
                val imc = peso / (altura * altura)

                // Obter classificação e sugestões
                val (classificacao, sugestoes) = getClassificacaoESugestoes(
                    imc,
                    spinnerSexo.selectedItemPosition,
                    spinnerFaixaEtaria.selectedItemPosition
                )

                // Exibir resultados
                tvResultadoIMC.text = String.format("Seu IMC: %.2f", imc)
                tvClassificacao.text = "Classificação: $classificacao"
                tvSugestoes.text = "Sugestões: $sugestoes"
                cardResultado.visibility = View.VISIBLE

            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Digite valores válidos", Toast.LENGTH_SHORT).show()
            }
        }

        btnSalvar.setOnClickListener {
            // Lógica para salvar no banco de dados
            Toast.makeText(this, "Resultado salvo com sucesso!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getClassificacaoESugestoes(imc: Double, sexo: Int, faixaEtaria: Int): Pair<String, String> {
        // Lógica para classificação baseada em sexo/faixa etária (exemplo simplificado)
        val classificacao = when {
            imc < 18.5 -> "Abaixo do peso"
            imc < 25 -> "Peso normal"
            imc < 30 -> "Sobrepeso"
            imc < 35 -> "Obesidade Grau I"
            imc < 40 -> "Obesidade Grau II"
            else -> "Obesidade Grau III"
        }

        val sugestoes = when (classificacao) {
            "Abaixo do peso" -> "Considere aumentar a ingestão calórica com alimentos nutritivos. Consulte um nutricionista."
            "Peso normal" -> "Mantenha hábitos saudáveis: alimentação equilibrada e exercícios regulares."
            "Sobrepeso" -> "Reduza alimentos processados e aumente a atividade física. Caminhadas diárias são um bom início."
            "Obesidade Grau I" -> "Busque orientação profissional para um plano de emagrecimento seguro. Evite dietas radicais."
            "Obesidade Grau II" -> "Procure acompanhamento médico e nutricional. Atividade física moderada é recomendada."
            else -> "Busque ajuda médica imediatamente. A obesidade mórbida requer tratamento multidisciplinar."
        }

        return Pair(classificacao, sugestoes)
    }
}