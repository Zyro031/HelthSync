import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.example.pi.R

class MassaLivreActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_massa_livre)

        val etPesoTotal = findViewById<EditText>(R.id.etPesoTotal)
        val etGorduraCorporal = findViewById<EditText>(R.id.etGorduraCorporal)
        val tvNaoSeiGordura = findViewById<TextView>(R.id.tvNaoSeiGordura)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val cardResultado = findViewById<CardView>(R.id.cardResultado)
        val tvMassaLivre = findViewById<TextView>(R.id.tvMassaLivre)
        val tvMassaGorda = findViewById<TextView>(R.id.tvMassaGorda)
        val tvClassificacao = findViewById<TextView>(R.id.tvClassificacao)
        val btnSalvar = findViewById<Button>(R.id.btnSalvar)

        // Redirecionar para tela de gordura corporal se não souber
        tvNaoSeiGordura.setOnClickListener {
            startActivity(Intent(this, BfActivity::class.java))
        }

        btnCalcular.setOnClickListener {
            val pesoText = etPesoTotal.text.toString()
            val gorduraText = etGorduraCorporal.text.toString()

            if (pesoText.isEmpty() || gorduraText.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                val pesoTotal = pesoText.toDouble()
                val percentualGordura = gorduraText.toDouble()

                // Calcular massa gorda e massa livre
                val massaGorda = pesoTotal * (percentualGordura / 100)
                val massaLivre = pesoTotal - massaGorda

                // Classificação baseada na massa livre
                val classificacao = when {
                    massaLivre < pesoTotal * 0.7 -> "Baixa massa magra"
                    massaLivre < pesoTotal * 0.85 -> "Massa magra adequada"
                    else -> "Alta massa magra"
                }

                // Exibir resultados
                tvMassaLivre.text = String.format("Sua massa livre: %.2f kg", massaLivre)
                tvMassaGorda.text = String.format("Sua massa gorda: %.2f kg", massaGorda)
                tvClassificacao.text = "Classificação: $classificacao"
                cardResultado.visibility = View.VISIBLE

            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Digite valores válidos", Toast.LENGTH_SHORT).show()
            }
        }

        btnSalvar.setOnClickListener {
            // Lógica para salvar no banco de dados
            Toast.makeText(this, "Resultado salvo com sucesso!", Toast.LENGTH_SHORT).show()
        }
    }

    class BfActivity {

    }
}