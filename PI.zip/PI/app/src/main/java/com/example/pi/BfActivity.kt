import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.example.pi.R

class BfActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bf)

        val etPeso = findViewById<EditText>(R.id.etPeso)
        val etAltura = findViewById<EditText>(R.id.etAltura)
        val etIdade = findViewById<EditText>(R.id.etIdade)
        val spinnerSexo = findViewById<Spinner>(R.id.spinnerSexo)
        val etGorduraCorporal = findViewById<EditText>(R.id.etGorduraCorporal)
        val tvNaoSei = findViewById<TextView>(R.id.tvNaoSei)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val cardTabelaPadrao = findViewById<CardView>(R.id.cardTabelaPadrao)
        val cardResultado = findViewById<CardView>(R.id.cardResultado)
        val tvResultadoGordura = findViewById<TextView>(R.id.tvResultadoGordura)
        val tvClassificacao = findViewById<TextView>(R.id.tvClassificacao)
        val tvMassaMagra = findViewById<TextView>(R.id.tvMassaMagra)
        val tvTaxaMetabolica = findViewById<TextView>(R.id.tvTaxaMetabolica)
        val btnSalvar = findViewById<Button>(R.id.btnSalvar)

        // Mostrar/ocultar tabela padrão
        tvNaoSei.setOnClickListener {
            if (cardTabelaPadrao.visibility == View.GONE) {
                cardTabelaPadrao.visibility = View.VISIBLE
            } else {
                cardTabelaPadrao.visibility = View.GONE
            }
        }

        btnCalcular.setOnClickListener {
            val pesoText = etPeso.text.toString()
            val alturaText = etAltura.text.toString()
            val idadeText = etIdade.text.toString()
            val gorduraText = etGorduraCorporal.text.toString()

            if (pesoText.isEmpty() || alturaText.isEmpty() || idadeText.isEmpty()) {
                Toast.makeText(this, "Preencha peso, altura e idade", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                val peso = pesoText.toDouble()
                val altura = alturaText.toDouble() / 100 // Converter cm para metros
                val idade = idadeText.toInt()
                val sexo = spinnerSexo.selectedItemPosition
                var gordura = 0.0

                // Se o usuário informou a gordura, usa esse valor
                if (gorduraText.isNotEmpty()) {
                    gordura = gorduraText.toDouble()
                } else {
                    // Estimar gordura corporal usando fórmula de Deurenberg
                    gordura = (1.20 * (peso / (altura * altura))) + (0.23 * idade) - (10.8 * sexo) - 5.4
                }

                // Calcular massa magra
                val massaMagra = peso * (1 - gordura / 100)

                // Calcular taxa metabólica basal (fórmula de Mifflin-St Jeor)
                val tmb = if (sexo == 0) { // Masculino
                    (10 * peso) + (6.25 * (altura * 100)) - (5 * idade) + 5
                } else { // Feminino
                    (10 * peso) + (6.25 * (altura * 100)) - (5 * idade) - 161
                }

                // Classificação baseada em sexo e idade
                val classificacao = when {
                    sexo == 0 && idade < 40 -> when {
                        gordura < 8 -> "Muito baixo"
                        gordura < 19 -> "Normal"
                        gordura < 25 -> "Elevado"
                        else -> "Muito elevado"
                    }
                    sexo == 0 && idade < 60 -> when {
                        gordura < 11 -> "Muito baixo"
                        gordura < 22 -> "Normal"
                        gordura < 27 -> "Elevado"
                        else -> "Muito elevado"
                    }
                    sexo == 0 -> when {
                        gordura < 13 -> "Muito baixo"
                        gordura < 25 -> "Normal"
                        gordura < 30 -> "Elevado"
                        else -> "Muito elevado"
                    }
                    sexo == 1 && idade < 40 -> when {
                        gordura < 21 -> "Muito baixo"
                        gordura < 33 -> "Normal"
                        gordura < 39 -> "Elevado"
                        else -> "Muito elevado"
                    }
                    sexo == 1 && idade < 60 -> when {
                        gordura < 23 -> "Muito baixo"
                        gordura < 35 -> "Normal"
                        gordura < 40 -> "Elevado"
                        else -> "Muito elevado"
                    }
                    else -> when {
                        gordura < 24 -> "Muito baixo"
                        gordura < 36 -> "Normal"
                        gordura < 42 -> "Elevado"
                        else -> "Muito elevado"
                    }
                }

                // Exibir resultados
                tvResultadoGordura.text = String.format("Seu percentual de gordura: %.1f%%", gordura)
                tvClassificacao.text = "Classificação: $classificacao"
                tvMassaMagra.text = String.format("Massa magra estimada: %.1f kg", massaMagra)
                tvTaxaMetabolica.text = String.format("Taxa metabólica basal: %.0f kcal/dia", tmb)
                cardResultado.visibility = View.VISIBLE

            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Digite valores válidos", Toast.LENGTH_SHORT).show()
            }
        }

        btnSalvar.setOnClickListener {
            // Lógica para salvar no banco de dados
            Toast.makeText(this, "Resultado salvo com sucesso!", Toast.LENGTH_SHORT).show()
        }
    }
}