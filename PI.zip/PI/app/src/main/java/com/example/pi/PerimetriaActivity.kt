import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.example.pi.R

class PerimetriaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perimetria)

        val etAbdomen = findViewById<EditText>(R.id.etAbdomen)
        val etQuadril = findViewById<EditText>(R.id.etQuadril)
        val etPescoco = findViewById<EditText>(R.id.etPescoco)
        val etAltura = findViewById<EditText>(R.id.etAltura)
        val spinnerSexo = findViewById<Spinner>(R.id.spinnerSexo)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val cardResultado = findViewById<CardView>(R.id.cardResultado)
        val tvRcq = findViewById<TextView>(R.id.tvRcq)
        val tvClassificacaoRcq = findViewById<TextView>(R.id.tvClassificacaoRcq)
        val tvIac = findViewById<TextView>(R.id.tvIac)
        val tvClassificacaoIac = findViewById<TextView>(R.id.tvClassificacaoIac)
        val btnSalvar = findViewById<Button>(R.id.btnSalvar)

        btnCalcular.setOnClickListener {
            val abdomenText = etAbdomen.text.toString()
            val quadrilText = etQuadril.text.toString()
            val pescocoText = etPescoco.text.toString()
            val alturaText = etAltura.text.toString()

            if (abdomenText.isEmpty() || quadrilText.isEmpty() || pescocoText.isEmpty() || alturaText.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                val abdomen = abdomenText.toDouble()
                val quadril = quadrilText.toDouble()
                val pescoco = pescocoText.toDouble()
                val altura = alturaText.toDouble()
                val sexo = spinnerSexo.selectedItemPosition

                // Calcular RCQ (Relação Cintura-Quadril)
                val rcq = abdomen / quadril

                // Classificação RCQ
                val classificacaoRcq = when {
                    sexo == 0 && rcq < 0.90 -> "Baixo risco"
                    sexo == 0 && rcq < 1.0 -> "Risco moderado"
                    sexo == 0 -> "Risco alto"
                    sexo == 1 && rcq < 0.80 -> "Baixo risco"
                    sexo == 1 && rcq < 0.85 -> "Risco moderado"
                    else -> "Risco alto"
                }

                // Calcular IAC (Índice de Adiposidade Corporal)
                val iac = if (sexo == 0) {
                    (abdomen / (altura * Math.sqrt(altura))) - 18
                } else {
                    (abdomen / (altura * Math.sqrt(altura))) - 38
                }

                // Classificação IAC
                val classificacaoIac = when {
                    iac < 8 -> "Magreza extrema"
                    iac < 21 -> "Normal"
                    iac < 26 -> "Sobrepeso"
                    else -> "Obesidade"
                }

                // Exibir resultados
                tvRcq.text = String.format("RCQ (Relação Cintura-Quadril): %.2f", rcq)
                tvClassificacaoRcq.text = "Classificação RCQ: $classificacaoRcq"
                tvIac.text = String.format("IAC (Índice de Adiposidade Corporal): %.2f", iac)
                tvClassificacaoIac.text = "Classificação IAC: $classificacaoIac"
                cardResultado.visibility = View.VISIBLE

            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Digite valores válidos", Toast.LENGTH_SHORT).show()
            }
        }

        btnSalvar.setOnClickListener {
            // Lógica para salvar no banco de dados
            Toast.makeText(this, "Resultado salvo com sucesso!", Toast.LENGTH_SHORT).show()
        }
    }
}